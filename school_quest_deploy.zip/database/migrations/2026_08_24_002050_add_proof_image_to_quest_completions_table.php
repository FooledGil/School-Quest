<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (!Schema::hasColumn('quest_completions', 'proof_image')) {
            Schema::table('quest_completions', function (Blueprint $table) {
                $table->string('proof_image')->nullable()->after('proof_text');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('quest_completions', function (Blueprint $table) {
            $table->dropColumn('proof_image');
        });
    }
};
