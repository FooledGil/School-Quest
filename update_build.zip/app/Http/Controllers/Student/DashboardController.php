<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\Schedule;
use App\Models\Quest;
use App\Models\QuestCompletion;
use App\Models\Achievement;
use App\Services\QuestGeneratorService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use App\Services\ExpService;

class DashboardController extends Controller
{
    public function index(QuestGeneratorService $questService)
    {
        $user = Auth::user();
        
        // Ensure daily quests are generated
        $questService->generateForUser($user);

        $today = Carbon::today();
        $dayOfWeek = $today->dayOfWeekIso;

        $schedules = Schedule::with('subject')
            ->where('class', $user->class)
            ->where('day_of_week', $dayOfWeek)
            ->orderBy('time_start')
            ->get();

        $completedQuestIds = $user->questCompletions()
            ->whereDate('completed_at', $today)
            ->pluck('quest_id')
            ->toArray();

        $recentQuests = Quest::where(function($query) use ($today, $user) {
                $query->where(function($q) use ($today, $user) {
                    $q->where('type', 'main')
                      ->where('available_date', $today->toDateString())
                      ->where(function($sub) use ($user) {
                          $sub->whereNull('class')->orWhere('class', $user->class);
                      });
                })->orWhere(function($q) {
                    $q->where('type', 'additional')->where('is_active', true);
                });
            })
            ->whereNotIn('id', $completedQuestIds)
            ->take(4)
            ->get();

        $allAchievements = Achievement::all();
        $userAchievementIds = $user->achievements()->pluck('achievement_id')->toArray();

        $achievements = $allAchievements->map(function($ach) use ($userAchievementIds) {
            $ach->isUnlocked = in_array($ach->id, $userAchievementIds);
            return $ach;
        });

        $rankPosition = \App\Models\User::where('role', 'student')
            ->where(function ($query) use ($user) {
                $query->where('exp', '>', $user->exp ?? 0)
                      ->orWhere(function ($q) use ($user) {
                          $q->where('exp', $user->exp ?? 0)
                            ->where('id', '<', $user->id);
                      });
            })
            ->count() + 1;

        $questsCompletedCount = $user->questCompletions()->count();

        $stats = [
            'exp' => $user->exp ?? 0,
            'totalExp' => $user->exp ?? 0,
            'level' => $user->level ?? 1,
            'rank' => $user->rank_name ?? 'Novice',
            'rankPosition' => $rankPosition,
            'streak' => $user->streak_days ?? 0,
            'questsCompleted' => $questsCompletedCount,
            'completedQuests' => $questsCompletedCount,
            'nextLevelExp' => $user->next_level_exp ?? 150,
            'currentLevelBaseExp' => $user->current_level_base_exp ?? 0,
            'expInLevel' => $user->exp_in_level ?? ($user->exp ?? 0),
            'expNeededInLevel' => $user->exp_needed_in_level ?? 150,
            'expPercentage' => $user->exp_percentage ?? 0,
            'expRemaining' => $user->exp_remaining ?? 150,
        ];

        return Inertia::render('Student/Dashboard', [
            'user' => $user,
            'schedules' => $schedules,
            'stats' => $stats,
            'recentQuests' => $recentQuests,
            'achievements' => $achievements,
        ]);
    }
}
